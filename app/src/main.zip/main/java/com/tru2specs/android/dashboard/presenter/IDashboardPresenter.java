package com.tru2specs.android.dashboard.presenter;

/**
 * Created by GP00471911 on 29-06-2017.
 */

public interface IDashboardPresenter {
    void getDashboardData();
    void doLogin();
}
