package com.tru2specs.android.basicinfo.listener;

/**
 * Created by GP00471911 on 19-06-2017.
 */

public interface OnBasicInfoFinishedListener {
    void onBasicInfoSuccess();
    void onBasicInfoFailure(String message);
}
