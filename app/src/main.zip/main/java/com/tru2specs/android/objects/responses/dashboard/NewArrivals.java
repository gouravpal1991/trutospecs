package com.tru2specs.android.objects.responses.dashboard;

/**
 * Created by palgour on 9/26/17.
 */

public class NewArrivals {
}
