package com.tru2specs.android.store.presenter;

/**
 * Created by GP00471911 on 28-06-2017.
 */

public interface IStorePresenter {
    void getStores();
}
