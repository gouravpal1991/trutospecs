package com.tru2specs.android.productlisting;

import android.content.Context;
import android.os.Build;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.tru2specs.android.R;

import java.util.ArrayList;


public class ProductRecyclerViewAdapter extends RecyclerView.Adapter<ProductRecyclerViewAdapter.ViewHolder> {
    private ArrayList<String> productList;
    private Context context;

    public ProductRecyclerViewAdapter(Context context) {
        this.context = context;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.product_list_row, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, int i) {

        viewHolder.txt_product_name.setText("Vincent Chase Polarized");
        viewHolder.txt_product_price.setText("Rs 1298");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            viewHolder.img_product.setImageDrawable(context.getDrawable(R.drawable.bear));
        }
    }

    @Override
    public int getItemCount() {
        return 10;// productList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView txt_product_name;
        private TextView txt_product_price;
        private ImageView img_product;

        public ViewHolder(View view) {
            super(view);

            txt_product_name = (TextView) view.findViewById(R.id.txt_product_name);
            txt_product_price = (TextView) view.findViewById(R.id.txt_product_price);
            img_product = (ImageView) view.findViewById(R.id.img_product);
        }
    }

}

