package com.tru2specs.android.cart.presenter;

/**
 * Created by palgour on 11/19/17.
 */

public interface ICartPresenter {
    void attemptFetchCartItems();
}
