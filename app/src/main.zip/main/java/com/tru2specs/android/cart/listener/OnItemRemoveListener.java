package com.tru2specs.android.cart.listener;

/**
 * Created by palgour on 11/19/17.
 */

public interface OnItemRemoveListener {
    void onRemove(String productId);
}
