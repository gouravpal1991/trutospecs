package com.tru2specs.android.productlisting;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

public class ProductListingViewPagerAdapter extends FragmentPagerAdapter {

    public ProductListingViewPagerAdapter(FragmentManager fm) {
        super(fm);
    }

    @Override
    public Fragment getItem(int position) {
        Fragment fragment = null;
        if (position == 0) {
            fragment = new ProductListFragment();
        } else if (position == 1) {
            fragment = new ProductListFragment();
        } else if (position == 2) {
            fragment = new ProductListFragment();
        }
        return fragment;
    }

    @Override
    public int getCount() {
        return 3;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        String title = null;
        if (position == 0) {
            title = "EYE GLASSES";
        } else if (position == 1) {
            title = "SUNGLASSES";
        } else if (position == 2) {
            title = "CONTACT LENSES";
        }
        return title;
    }
}
