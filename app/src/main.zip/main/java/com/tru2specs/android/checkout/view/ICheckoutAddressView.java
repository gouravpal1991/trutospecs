package com.tru2specs.android.checkout.view;

/**
 * Created by palgour on 8/26/17.
 */

public interface ICheckoutAddressView {
    void init();
}
