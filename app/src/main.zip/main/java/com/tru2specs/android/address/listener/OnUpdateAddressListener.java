package com.tru2specs.android.address.listener;

import com.tru2specs.android.objects.responses.savedaddresses.Address;

/**
 * Created by palgour on 8/25/17.
 */

public interface OnUpdateAddressListener {
    void updateAddress(Address address);
}
