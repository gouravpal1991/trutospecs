package com.tru2specs.android.menu.model;

import android.os.Parcel;
import android.os.Parcelable;

import java.util.ArrayList;

/**
 * Created by palgour on 10/30/17.
 */

public class MenuItem implements Parcelable {
    private String categoryName;
    private ArrayList<String> menuItems;

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public ArrayList<String> getMenuItems() {
        return menuItems;
    }

    public void setMenuItems(ArrayList<String> menuItems) {
        this.menuItems = menuItems;
    }


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.categoryName);
        dest.writeStringList(this.menuItems);
    }

    public MenuItem() {
    }

    public MenuItem(String categoryName, ArrayList<String> menuItems) {
        this.categoryName=categoryName;
        this.menuItems=menuItems;
    }

    protected MenuItem(Parcel in) {
        this.categoryName = in.readString();
        this.menuItems = in.createStringArrayList();
    }

    public static final Parcelable.Creator<MenuItem> CREATOR = new Parcelable.Creator<MenuItem>() {
        @Override
        public MenuItem createFromParcel(Parcel source) {
            return new MenuItem(source);
        }

        @Override
        public MenuItem[] newArray(int size) {
            return new MenuItem[size];
        }
    };
}
