package com.tru2specs.android.productslist.view;

import com.tru2specs.android.objects.responses.productlisting.Product;

import java.util.ArrayList;

/**
 * Created by palgour on 11/19/17.
 */

public interface IProductListView {
    void setScreenDeails();
    void setProducts(ArrayList<Product> products);
}
